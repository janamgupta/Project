package com.cts.buyer.services;

import org.springframework.stereotype.Service;

import com.cts.buyer.entity.BuyerInfo;
import com.cts.buyer.entity.CartItems;

@Service
public class CartService {
	
	public CartService addCart(CartItems cartItem, Integer buyerId) {
		
	}
}
