package com.cts.buyer.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.buyer.entity.BuyerInfo;
import com.cts.buyer.services.BuyerService;

@RestController
public class BuyerController {
	
	@Autowired
	private BuyerService buyerservice;
	
	@RequestMapping(value = "adduser", method = RequestMethod.POST, produces = "application/json")
	public BuyerInfo addProduct(@RequestBody BuyerInfo buyer)
	{
		BuyerInfo buyerInfo = buyerservice.addBuyer(buyer);
		return buyerInfo;
	}
}
