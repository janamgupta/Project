package com.cts.buyer.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.buyer.entity.BuyerInfo;
import com.cts.buyer.entity.PurchaseHistory;
import com.cts.buyer.repository.IAddressRepository;
import com.cts.buyer.repository.IBuyerRepository;
import com.cts.buyer.repository.IPurchaseHistory;

@Service
public class BuyerService {
	
	@Autowired
	private IBuyerRepository buyerRepository;
	
	@Autowired
	private IAddressRepository addressRepository;
	
	@Autowired
	private IPurchaseHistory purchaseRepository;
	
	public BuyerInfo addBuyer(BuyerInfo buyer) {
		addressRepository.save(buyer.getBuyerAddress());
		return buyerRepository.save(buyer);
	}
	
	public List<PurchaseHistory> getPurchaseHistory(Integer buyerId){
		return purchaseRepository.getPurchaseHistory(buyerId);
	}
}
