package com.cts.buyer.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.buyer.entity.BuyerInfo;
import com.cts.buyer.entity.CartItems;
import com.cts.buyer.entity.Item;
import com.cts.buyer.entity.PurchaseHistory;
import com.cts.buyer.entity.TransactionHistory;
import com.cts.buyer.repository.IBuyerRepository;
import com.cts.buyer.repository.ICartRepository;
import com.cts.buyer.repository.IItemRepository;
import com.cts.buyer.repository.IPurchaseHistory;
import com.cts.buyer.repository.ITransactionHistory;

@Service
public class CartService {
	
	@Autowired
	private ICartRepository cartRepository;
	
	@Autowired
	private IBuyerRepository buyerRepository;
	
	@Autowired
	private ITransactionHistory transactionRepository;
	
	@Autowired
	private IPurchaseHistory purchaseHistory;
	
	@Autowired
	private IItemRepository itemRepository;
	
	public Optional<CartItems> addItemToCart(CartItems cartItem, Integer buyerId) {
		return buyerRepository.findById(buyerId).map(buyer -> {
            cartItem.setBuyer(buyer);
            return cartRepository.save(cartItem);
        });
	}
	
	public String deleteCartItem(Integer cartItemId) {
		cartRepository.deleteById(cartItemId);
		return "Deleted";
	}
	
	public String emptyCartItems(Integer buyerId) {
		cartRepository.deleteBybuyer(buyerId);
		return "deleted";
	}
	
	
	 public List<CartItems> getallCartItems(Integer buyerId){ 
		 List<CartItems>items = cartRepository.findAllCartItem(buyerId); 
		 return items; 
	}
	
	public CartItems updateCartItem(CartItems item, Integer cartItemId) {
		Optional<CartItems> cartItem = cartRepository.findById(cartItemId);
		if(cartItem.isPresent()) {
			CartItems newCartItem = cartItem.get();
			newCartItem.setQuantity(item.getQuantity());
			return cartRepository.save(newCartItem);
		}
		return null;
	}
	
	public String checkout(Integer buyerId) {
		Double totalAmount = 0.00;
		TransactionHistory transaction = null;
		PurchaseHistory purchase = null;
		List<CartItems> cartItems = cartRepository.findAllCartItem(buyerId);
		for(CartItems items : cartItems) {
			Optional<Item> item = itemRepository.findById(items.getCartItemId());
			totalAmount += item.get().getPrice();
		}
		Optional<BuyerInfo> buyer = buyerRepository.findById(buyerId);
		transaction  = new TransactionHistory();
		transaction.setTransactionAmount(totalAmount);
		transaction.setBuyer(buyer.get());
		transaction.setTransactionType("debited");
		transaction.setRemarks("paid");
		
		transactionRepository.save(transaction);
		
		for(CartItems items : cartItems) {
			purchase = new PurchaseHistory();
			Integer initialQuantity; 
			purchase.setBuyer(buyer.get());
			purchase.setTransaction(transaction);
			purchase.setItemId(items.getItemId());
			purchase.setRemarks("confirmed");
			purchase.setNumberOfItems(items.getQuantity());
			Optional<Item> item = itemRepository.findById(items.getItemId());
			Item updatedItem = item.get();
			initialQuantity = updatedItem.getStock();
			updatedItem.setStock(initialQuantity - items.getQuantity());
			itemRepository.save(updatedItem);
			purchaseHistory.save(purchase);
		}
		cartRepository.deleteBybuyer(buyerId);
		return "checkedout";
	}
}
