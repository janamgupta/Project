package com.cts.buyer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.buyer.entity.TransactionHistory;

@Repository
public interface ITransactionHistory extends JpaRepository<TransactionHistory, Integer>{

}
