package com.cts.buyer.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class PurchaseHistory {
	
	@Id
	@GeneratedValue
	private Integer purchaseHistoryId;
	@ManyToOne
	@JoinColumn(name = "buyerId")
	private BuyerInfo buyer;
	@ManyToOne
	@JoinColumn(name = "transactionId")
	private TransactionHistory transaction;
	@OneToOne
	private Item item;
	private Integer numberOfItems;
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateTime;
	private String remarks;
	
	
	public PurchaseHistory() {
		super();
	}
	
	
	public PurchaseHistory(Integer purchaseHistoryId, BuyerInfo buyer, TransactionHistory transaction, Item itemId,
			Integer numberOfItems, Date dateTime, String remarks) {
		super();
		this.purchaseHistoryId = purchaseHistoryId;
		this.buyer = buyer;
		this.transaction = transaction;
		this.item = itemId;
		this.numberOfItems = numberOfItems;
		this.dateTime = dateTime;
		this.remarks = remarks;
	}


	public Integer getPurchaseHistoryId() {
		return purchaseHistoryId;
	}


	public void setPurchaseHistoryId(Integer purchaseHistoryId) {
		this.purchaseHistoryId = purchaseHistoryId;
	}

	public BuyerInfo getBuyer() {
		return buyer;
	}


	public void setBuyer(BuyerInfo buyer) {
		this.buyer = buyer;
	}


	public TransactionHistory getTransaction() {
		return transaction;
	}


	public void setTransaction(TransactionHistory transaction) {
		this.transaction = transaction;
	}


	public Item getItemId() {
		return item;
	}


	public void setItemId(Item itemId) {
		this.item = itemId;
	}


	public Integer getNumberOfItems() {
		return numberOfItems;
	}


	public void setNumberOfItems(Integer numberOfItems) {
		this.numberOfItems = numberOfItems;
	}


	public Date getDateTime() {
		return dateTime;
	}


	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
