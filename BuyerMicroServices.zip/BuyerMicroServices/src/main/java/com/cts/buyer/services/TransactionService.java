package com.cts.buyer.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cts.buyer.entity.TransactionHistory;
import com.cts.buyer.repository.IBuyerRepository;
import com.cts.buyer.repository.ITransactionHistory;

@Service
public class TransactionService {
	
	@Autowired
	private ITransactionHistory iTransactionHistory;
	
	@Autowired
	private IBuyerRepository buyer;
	
	public Optional<TransactionHistory> addTransaction(TransactionHistory transaction, Integer buyerId) {
		return buyer.findById(buyerId).map(buyer -> {
            transaction.setBuyer(buyer);
            return iTransactionHistory.save(transaction);
        });
	}
}
