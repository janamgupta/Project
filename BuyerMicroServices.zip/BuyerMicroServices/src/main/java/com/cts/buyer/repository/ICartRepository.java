package com.cts.buyer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.buyer.entity.CartItems;

@Repository
public interface ICartRepository extends JpaRepository<CartItems, Integer>{

}
