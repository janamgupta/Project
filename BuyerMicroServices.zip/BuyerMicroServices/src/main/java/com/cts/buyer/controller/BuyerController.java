package com.cts.buyer.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.buyer.entity.BuyerInfo;
import com.cts.buyer.entity.CartItems;
import com.cts.buyer.services.BuyerService;
import com.cts.buyer.services.CartService;

@RestController
public class BuyerController {
	
	@Autowired
	private BuyerService buyerservice;
	
	@Autowired
	private CartService cartService;
	@RequestMapping(value = "adduser", method = RequestMethod.POST, produces = "application/json")
	public BuyerInfo addProduct(@RequestBody BuyerInfo buyer)
	{
		BuyerInfo buyerInfo = buyerservice.addBuyer(buyer);
		return buyerInfo;
	}
	
	@RequestMapping(value = "Buyer/{buyerId}/addcartitem", method = RequestMethod.POST, produces = "application/json")
	public CartItems addCartItems(@PathVariable(value = "buyerId") Integer buyerId,@RequestBody CartItems cartItem) {
		Optional<CartItems> savedItem = cartService.addCart(cartItem, buyerId);
		return savedItem.get();
	}
}
