package com.cts.buyer.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.buyer.entity.BuyerInfo;
import com.cts.buyer.entity.CartItems;
import com.cts.buyer.entity.Item;
import com.cts.buyer.entity.PurchaseHistory;
import com.cts.buyer.entity.TransactionHistory;
import com.cts.buyer.repository.IBuyerRepository;
import com.cts.buyer.repository.ICartRepository;

@Service
public class CartService {
	
	@Autowired
	private ICartRepository cartRepository;
	
	@Autowired
	private IBuyerRepository buyerRepository;
	
	@Autowired
	private TransactionService transactionHistoryServices;
	public Optional<CartItems> addCart(CartItems cartItem, Integer buyerId) {
		return buyerRepository.findById(buyerId).map(buyer -> {
            cartItem.setBuyer(buyer);
            return cartRepository.save(cartItem);
        });
	}
	
	public void checkout(CartItems cartItem, PurchaseHistory purchaseHistory, TransactionHistory transactionHistory, Integer buyerId) {
		transactionHistoryServices.addTransaction(transactionHistory, buyerId);
	}
}
