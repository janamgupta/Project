package com.emart.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emart.entity.Seller;
import com.emart.repository.IAddress;
import com.emart.repository.ISeller;

@Service
public class SellerService {
	
	@Autowired
	private ISeller sellerRepository;
	
	@Autowired
	private IAddress addressRepository;
	
	public Seller addSeller(Seller seller) {
		addressRepository.save(seller.getPostalAddress());
		return sellerRepository.save(seller);
	}
}
