package com.emart.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.emart.entity.Items;
import com.emart.repository.IItem;

public class ItemService {

	@Autowired
	private IItem itemRepository;
	
	public Items addItems(Items item) {
		return itemRepository.save(item);
	}
	
	public List<Items> getAllitems(Integer sellerId){
		return itemRepository.findBySellerId(sellerId);
	}
	
	public void deleteitem(Integer sellerId, Integer itemId) {
		itemRepository.deleteItemById(sellerId, itemId);
	}
}
