package com.cts.buyer.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class CartItems {
	
	@Id
	@GeneratedValue
	private Integer cartItemId;
	private Integer itemId;
	private Integer quantity;
	@ManyToOne
	@JoinColumn(name = "buyerId")
	private BuyerInfo buyer;
	
	public CartItems(Integer cartItemId, Integer itemId, Integer quantity, BuyerInfo buyer) {
		super();
		this.cartItemId = cartItemId;
		this.itemId = itemId;
		this.quantity = quantity;
		this.buyer = buyer;
	}


	public CartItems() {
		// TODO Auto-generated constructor stub
	}


	public Integer getCartItemId() {
		return cartItemId;
	}


	public void setCartItemId(Integer cartItemId) {
		this.cartItemId = cartItemId;
	}


	public Integer getItemId() {
		return itemId;
	}


	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}


	public Integer getQuantity() {
		return quantity;
	}


	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}


	public BuyerInfo getBuyer() {
		return buyer;
	}


	public void setBuyer(BuyerInfo buyer) {
		this.buyer = buyer;
	}
}
