package com.cts.buyer.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.buyer.entity.CartItems;
import com.cts.buyer.repository.BuyerRepository;
import com.cts.buyer.repository.CartRepository;

@Service
public class CartService {
	
	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private BuyerRepository buyerRepository;
	
	public Optional<CartItems> addCart(CartItems cartItem, Integer buyerId) {
		return buyerRepository.findById(buyerId).map(buyer -> {
            cartItem.setBuyer(buyer);
            return cartRepository.save(cartItem);
        });
	}
}
