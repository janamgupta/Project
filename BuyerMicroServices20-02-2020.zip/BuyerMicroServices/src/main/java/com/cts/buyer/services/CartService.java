package com.cts.buyer.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.buyer.entity.BuyerInfo;
import com.cts.buyer.entity.CartItems;
import com.cts.buyer.entity.Item;
import com.cts.buyer.entity.PurchaseHistory;
import com.cts.buyer.entity.TransactionHistory;
import com.cts.buyer.repository.IBuyerRepository;
import com.cts.buyer.repository.ICartRepository;

@Service
public class CartService {
	
	@Autowired
	private ICartRepository cartRepository;
	
	@Autowired
	private IBuyerRepository buyerRepository;
	
	@Autowired
	private TransactionService transactionHistoryServices;
	
	public Optional<CartItems> addItemToCart(CartItems cartItem, Integer buyerId) {
		return buyerRepository.findById(buyerId).map(buyer -> {
            cartItem.setBuyer(buyer);
            return cartRepository.save(cartItem);
        });
	}
	
	public String deleteCartItem(Integer cartItemId) {
		cartRepository.deleteById(cartItemId);
		return "Deleted";
	}
	
	public String emptyCartItems(Integer buyerId) {
		Optional<BuyerInfo> buyer = buyerRepository.findById(buyerId);
		cartRepository.deleteBybuyer(buyer.get());
		return "deleted";
	}
	
	public List<CartItems> getallCartItems(Integer buyerId){
		List<CartItems> items = cartRepository.findAllBybuyer(buyerId);
		return items;
	}
	public void checkout(CartItems cartItem, PurchaseHistory purchaseHistory, TransactionHistory transactionHistory, Integer buyerId) {
		transactionHistoryServices.addTransaction(transactionHistory, buyerId);
	}
}
